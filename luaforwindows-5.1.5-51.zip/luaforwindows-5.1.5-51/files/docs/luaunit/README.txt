		luaunit.lua  by Philippe Fremy

Luaunit is a testing framework for Lua, in the spirit of Extrem Programming.

Luaunit is derived from the initial work of Ryu Gwang but has evolved a lot
from the original code as my understanding of lua progressed.

Luaunit should work on all platforms supported by lua. It was tested on
Windows XP and Gentoo Linux.

Luaunit is used extensively in yzis (www.yzis.org), a vi clone, in order to
test the lua binding of the editor.

You can download luaunit from:
http://luaforge.net/projects/luaunit/


History:
========

v1.2: first public release

v1.3: ported to lua 5.1

v2.0: many usability and helper functions added. See the top of the source for all the details.

