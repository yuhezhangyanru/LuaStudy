gzio 0.9.0
------------------------------

The Lua gzip file I/O module emulates the standard I/O module, but operates on compressed gzip format files.

gzio is free software and uses the same license as Lua 5.1.

Look at the examples/gzio for how to use the module.